package eg.edu.cu.hostel.meals

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import java.time.LocalDate
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * ينفذ خطوات الحجز الفعلي على موقع الزهراء (جامعة القاهرة) بالضبط كما في صور الموقع:
 * 1. يفتح https://hostel.cu.edu.eg/studentLogin ويكتب الرقم القومي وكلمة المرور ويضغط زر "دخول".
 * 2. ينتقل إلى https://hostel.cu.edu.eg/studentHome ويفتح قائمة "الوجبات" -> "حجز الوجبات".
 * 3. يحدد مربعات الاختيار المتاحة لليوم المفتوح ("غداء" و "عشاء") حسب خطة اليوم ويضغط زر "حفظ".
 */
class HostelPortalClient(private val context: Context) {

    companion object {
        const val LOGIN_URL = "https://hostel.cu.edu.eg/studentLogin"
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun bookMealsForDate(
        nationalId: String,
        password: String,
        targetDate: LocalDate,
        bookLunch: Boolean,
        bookDinner: Boolean
    ): Result<String> {
        val latch = CountDownLatch(1)
        var bookingSucceeded = false

        val jsStep = """
            (function() {
                function setVal(el, val) {
                    var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                    if (setter) setter.call(el, val); else el.value = val;
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                }
                if (location.pathname.toLowerCase().includes('login')) {
                    var pass = document.querySelector('input[type="password"]');
                    var inputs = document.querySelectorAll('input:not([type="password"]):not([type="hidden"]):not([type="checkbox"])');
                    if (pass && inputs.length > 0) {
                        setVal(inputs[0], '$nationalId');
                        setVal(pass, '$password');
                        var btn = Array.from(document.querySelectorAll('button, input[type="submit"], a, .btn')).find(function(b) {
                            return (b.textContent || b.value || '').trim().includes('دخول');
                        });
                        if (btn) setTimeout(function() { btn.click(); }, 400);
                    }
                    return 'LOGIN_PAGE';
                }
                if (location.pathname.toLowerCase().includes('home')) {
                    var saveBtn = Array.from(document.querySelectorAll('button, a, input[type="button"], input[type="submit"], .btn')).find(function(el) {
                        return (el.textContent || el.value || '').trim() === 'حفظ';
                    });
                    var cbs = Array.from(document.querySelectorAll('input[type="checkbox"]:not(:disabled)'));
                    if (saveBtn && cbs.length > 0) {
                        var wantL = $bookLunch;
                        var wantD = $bookDinner;
                        cbs.forEach(function(cb, i) {
                            var txt = (cb.parentElement ? cb.parentElement.textContent : '');
                            var isL = txt.includes('غداء') || txt.includes('غدا') || (cbs.length === 2 && i === 0);
                            var isD = txt.includes('عشاء') || txt.includes('عشا') || (cbs.length === 2 && i === 1);
                            if (isL && cb.checked !== wantL) cb.click();
                            if (isD && cb.checked !== wantD) cb.click();
                        });
                        setTimeout(function() { saveBtn.click(); }, 500);
                        return 'SAVED_MEALS';
                    }
                    var bookLink = Array.from(document.querySelectorAll('a, li, span, div')).find(function(el) {
                        return (el.textContent || '').trim() === 'حجز الوجبات';
                    });
                    if (bookLink) { bookLink.click(); return 'CLICKED_BOOK_MEALS'; }
                    var mealsMenu = Array.from(document.querySelectorAll('a, li, span, div')).find(function(el) {
                        return (el.textContent || '').trim() === 'الوجبات';
                    });
                    if (mealsMenu) { mealsMenu.click(); return 'CLICKED_MEALS_MENU'; }
                }
                return 'WAITING';
            })();
        """.trimIndent()

        Handler(Looper.getMainLooper()).post {
            val webView = WebView(context.applicationContext)
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true

            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val h = Handler(Looper.getMainLooper())
                    for (step in 1..8) {
                        h.postDelayed({
                            if (!bookingSucceeded) {
                                view?.evaluateJavascript(jsStep) { result ->
                                    if (result != null && result.contains("SAVED_MEALS")) {
                                        bookingSucceeded = true
                                        h.postDelayed({ latch.countDown() }, 1500L)
                                    }
                                }
                            }
                        }, step * 2000L)
                    }
                }
            }
            webView.loadUrl(LOGIN_URL)
        }

        latch.await(30, TimeUnit.SECONDS)
        return if (bookingSucceeded) {
            Result.success("BOOKED")
        } else {
            Result.failure(Exception("RETRY_NEEDED"))
        }
    }
}
