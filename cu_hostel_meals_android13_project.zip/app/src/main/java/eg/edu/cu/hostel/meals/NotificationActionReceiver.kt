package eg.edu.cu.hostel.meals

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.time.LocalDate

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(1001)

        val targetDateStr = intent.getStringExtra("target_date") ?: return
        val prefs = SecurePrefs(context)
        runCatching {
            prefs.markUserInteracted(LocalDate.parse(targetDateStr))
        }

        when (intent.action) {
            "eg.edu.cu.hostel.meals.ACTION_BOOK_BOTH",
            "eg.edu.cu.hostel.meals.ACTION_BOOK_LUNCH",
            "eg.edu.cu.hostel.meals.ACTION_BOOK_DINNER" -> {
                val plan = intent.getStringExtra("meal_plan") ?: "both"
                val req = OneTimeWorkRequestBuilder<DailyMealWorker>()
                    .setConstraints(
                        Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                    )
                    .setInputData(
                        workDataOf(
                            "force_book_date" to targetDateStr,
                            "force_meal_plan" to plan
                        )
                    )
                    .build()
                WorkManager.getInstance(context).enqueue(req)
            }
            "eg.edu.cu.hostel.meals.ACTION_SKIP_DAY" -> {
                // تم تسجيل تفاعل الطالب بالرفض وإيقاف جميع الإشعارات التالية لهذا اليوم
            }
        }
    }
}
