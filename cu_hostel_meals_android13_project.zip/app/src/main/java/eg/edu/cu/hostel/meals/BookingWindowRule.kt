package eg.edu.cu.hostel.meals

import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

object BookingWindowRule {
    val CUTOFF_TIME: LocalTime = LocalTime.of(20, 0) // 8:00 PM

    fun getCurrentlyOpenBookingDate(now: LocalDateTime = LocalDateTime.now()): LocalDate {
        return if (now.toLocalTime().isBefore(CUTOFF_TIME)) {
            now.toLocalDate().plusDays(1)
        } else {
            now.toLocalDate().plusDays(2)
        }
    }

    fun getDelayUntilNext8PM(now: LocalDateTime = LocalDateTime.now()): Long {
        var target = LocalDateTime.of(now.toLocalDate(), CUTOFF_TIME)
        if (!now.isBefore(target)) {
            target = target.plusDays(1)
        }
        return Duration.between(now, target).toMillis().coerceAtLeast(1000L)
    }
}
