package eg.edu.cu.hostel.meals

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

class DailyMealWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val prefs = SecurePrefs(context)
        if (!prefs.hasAccount()) return Result.success()

        val forcedDateStr = inputData.getString("force_book_date")
        val forcedPlan = inputData.getString("force_meal_plan")
        val attemptIndex = inputData.getInt("attempt_index", 1)

        val targetDate = if (!forcedDateStr.isNullOrEmpty()) {
            LocalDate.parse(forcedDateStr)
        } else {
            BookingWindowRule.getCurrentlyOpenBookingDate(LocalDateTime.now())
        }

        if (prefs.isDateBooked(targetDate)) return Result.success()

        // 1. إذا كان الحجز إجبارياً من زر الإشعار أو كان اليوم ضمن جدول الحجز التلقائي
        if (!forcedPlan.isNullOrEmpty() || prefs.isDateScheduled(targetDate)) {
            val plan = forcedPlan ?: prefs.getMealPlanForDate(targetDate)
            val wantLunch = (plan == "both" || plan == "lunch")
            val wantDinner = (plan == "both" || plan == "dinner")

            val res = HostelPortalClient(context).bookMealsForDate(
                nationalId = prefs.getNationalId(),
                password = prefs.getPassword(),
                targetDate = targetDate,
                bookLunch = wantLunch,
                bookDinner = wantDinner
            )

            return if (res.isSuccess) {
                prefs.markDateBooked(targetDate, plan)
                if (prefs.areNotificationsEnabled()) {
                    val mealAr = when (plan) {
                        "lunch" -> "غدا فقط"
                        "dinner" -> "عشا فقط"
                        else -> "غدا و عشا"
                    }
                    showBookedConfirmationNotification(targetDate.toString(), mealAr)
                }
                Result.success()
            } else {
                // إذا كان الإنترنت ضعيفاً أو مقطوعاً، يعيد المحاولة تلقائياً عند استقرار الإنترنت
                Result.retry()
            }
        }

        // 2. إذا كان اليوم غير محدد في الجدول ولم يتفاعل معه المستخدم بعد -> إرسال سلسلة الإشعارات (8 مساءً، ثم +8 س، ثم +3 س)
        if (!prefs.hasUserInteracted(targetDate) && prefs.areNotificationsEnabled()) {
            val maxCount = prefs.getNotifCount()
            if (attemptIndex <= maxCount) {
                showAskUserNotification(targetDate.toString(), attemptIndex, maxCount)
                if (attemptIndex < maxCount) {
                    val waitHours = prefs.getIntervalHours(attemptIndex).toLong()
                    val nextReq = OneTimeWorkRequestBuilder<DailyMealWorker>()
                        .setInitialDelay(waitHours, TimeUnit.HOURS)
                        .setInputData(workDataOf("attempt_index" to (attemptIndex + 1)))
                        .setConstraints(
                            Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                        )
                        .build()
                    WorkManager.getInstance(context).enqueueUniqueWork(
                        "cu_followup_${targetDate}_${attemptIndex + 1}",
                        ExistingWorkPolicy.REPLACE,
                        nextReq
                    )
                }
            }
        }

        return Result.success()
    }

    private fun ensureChannel(nm: NotificationManager): String {
        val channelId = "cu_hostel_meals_channel"
        val channel = NotificationChannel(
            channelId,
            "حجز وجبات المدينة الجامعية",
            NotificationManager.IMPORTANCE_HIGH
        )
        nm.createNotificationChannel(channel)
        return channelId
    }

    private fun showAskUserNotification(dateStr: String, attempt: Int, maxCount: Int) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = ensureChannel(nm)

        fun buildActionPending(actionName: String, reqCode: Int, plan: String): PendingIntent {
            val intent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = actionName
                putExtra("target_date", dateStr)
                putExtra("meal_plan", plan)
            }
            return PendingIntent.getBroadcast(
                context, reqCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("إشعار ($attempt/$maxCount): حجز وجبات يوم $dateStr")
            .setContentText("فتح باب الحجز ليوم $dateStr. اختر الوجبة المطلوبة أو ارفض لإيقاف التنبيهات:")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(android.R.drawable.ic_input_add, "غدا و عشا", buildActionPending("eg.edu.cu.hostel.meals.ACTION_BOOK_BOTH", 201, "both"))
            .addAction(android.R.drawable.ic_input_add, "غدا فقط", buildActionPending("eg.edu.cu.hostel.meals.ACTION_BOOK_LUNCH", 202, "lunch"))
            .addAction(android.R.drawable.ic_delete, "رفض", buildActionPending("eg.edu.cu.hostel.meals.ACTION_SKIP_DAY", 204, "skip"))
            .build()

        nm.notify(1001, notification)
    }

    private fun showBookedConfirmationNotification(dateStr: String, mealAr: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = ensureChannel(nm)

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.checkbox_on_background)
            .setContentTitle("✅ تم حجز $mealAr")
            .setContentText("تم حجز ($mealAr) ليوم $dateStr بنجاح على موقع الزهراء للمدن الجامعية.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        nm.notify(1002, notification)
    }
}
