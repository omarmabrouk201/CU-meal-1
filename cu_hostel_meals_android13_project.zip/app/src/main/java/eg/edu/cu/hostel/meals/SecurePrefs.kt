package eg.edu.cu.hostel.meals

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.time.LocalDate

class SecurePrefs(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("cu_hostel_native_prefs", Context.MODE_PRIVATE)

    fun syncFromWebJson(jsonString: String) {
        runCatching {
            val obj = JSONObject(jsonString)
            val editor = prefs.edit()
            editor.putString("raw_state_json", jsonString)
            editor.putString("national_id", obj.optString("nationalId", ""))
            editor.putString("password", obj.optString("password", ""))
            editor.putBoolean("notifications_enabled", obj.optBoolean("notificationsEnabled", true))
            editor.putInt("notif_count", obj.optInt("notifCount", 3))

            val intervalsArr = obj.optJSONArray("notifIntervals")
            if (intervalsArr != null && intervalsArr.length() >= 2) {
                editor.putInt("interval_1", intervalsArr.optInt(0, 8))
                editor.putInt("interval_2", intervalsArr.optInt(1, 3))
                editor.putInt("interval_3", if (intervalsArr.length() >= 3) intervalsArr.optInt(2, 3) else 3)
            }

            val schedSet = mutableSetOf<String>()
            val schedArr = obj.optJSONArray("scheduledDates")
            if (schedArr != null) {
                for (i in 0 until schedArr.length()) schedSet.add(schedArr.getString(i))
            }
            editor.putStringSet("scheduled_dates", schedSet)

            val skipSet = mutableSetOf<String>()
            val skipArr = obj.optJSONArray("skippedDates")
            if (skipArr != null) {
                for (i in 0 until skipArr.length()) skipSet.add(skipArr.getString(i))
            }
            editor.putStringSet("skipped_dates", skipSet)

            val dayPlans = obj.optJSONObject("dayMealPlan")
            if (dayPlans != null) {
                editor.putString("day_meal_plans_json", dayPlans.toString())
            }
            editor.apply()
        }
    }

    fun getNationalId(): String = prefs.getString("national_id", "") ?: ""
    fun getPassword(): String = prefs.getString("password", "") ?: ""
    fun hasAccount(): Boolean = getNationalId().length == 14 && getPassword().isNotEmpty()
    fun areNotificationsEnabled(): Boolean = prefs.getBoolean("notifications_enabled", true)
    fun getNotifCount(): Int = prefs.getInt("notif_count", 3)
    fun getIntervalHours(attemptIndex: Int): Int {
        return when (attemptIndex) {
            1 -> prefs.getInt("interval_1", 8)
            2 -> prefs.getInt("interval_2", 3)
            else -> prefs.getInt("interval_3", 3)
        }
    }

    fun isDateScheduled(date: LocalDate): Boolean {
        val skipped = prefs.getStringSet("skipped_dates", emptySet()) ?: emptySet()
        if (skipped.contains(date.toString())) return false
        val sched = prefs.getStringSet("scheduled_dates", emptySet()) ?: emptySet()
        return sched.contains(date.toString())
    }

    fun getMealPlanForDate(date: LocalDate): String {
        val raw = prefs.getString("day_meal_plans_json", "{}") ?: "{}"
        return runCatching {
            val obj = JSONObject(raw)
            obj.optString(date.toString(), "both")
        }.getOrDefault("both")
    }

    fun markDateBooked(date: LocalDate, mealPlan: String) {
        val booked = (prefs.getStringSet("booked_dates", emptySet()) ?: emptySet()).toMutableSet()
        booked.add(date.toString())
        prefs.edit()
            .putStringSet("booked_dates", booked)
            .putString("booked_plan_${date}", mealPlan)
            .apply()
        markUserInteracted(date)
    }

    fun isDateBooked(date: LocalDate): Boolean {
        val booked = prefs.getStringSet("booked_dates", emptySet()) ?: emptySet()
        return booked.contains(date.toString())
    }

    fun markUserInteracted(date: LocalDate) {
        val set = (prefs.getStringSet("interacted_dates", emptySet()) ?: emptySet()).toMutableSet()
        set.add(date.toString())
        prefs.edit().putStringSet("interacted_dates", set).apply()
    }

    fun hasUserInteracted(date: LocalDate): Boolean {
        val set = prefs.getStringSet("interacted_dates", emptySet()) ?: emptySet()
        return set.contains(date.toString())
    }
}
