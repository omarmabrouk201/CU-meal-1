package eg.edu.cu.hostel.meals

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var mainWebView: WebView
    private lateinit var prefs: SecurePrefs

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = SecurePrefs(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }

        scheduleDaily8PMAutoBookingWorker()

        mainWebView = WebView(this)
        mainWebView.settings.javaScriptEnabled = true
        mainWebView.settings.domStorageEnabled = true
        mainWebView.webChromeClient = WebChromeClient()
        mainWebView.webViewClient = WebViewClient()
        mainWebView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        setContentView(mainWebView)
        mainWebView.loadUrl("file:///android_asset/index.html")
    }

    private fun scheduleDaily8PMAutoBookingWorker() {
        val delayMs = BookingWindowRule.getDelayUntilNext8PM()
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val dailyWork = PeriodicWorkRequestBuilder<DailyMealWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 15, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "cu_hostel_daily_8pm_worker",
            ExistingPeriodicWorkPolicy.UPDATE,
            dailyWork
        )
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun syncStateFromWeb(jsonPayload: String) {
            prefs.syncFromWebJson(jsonPayload)
            scheduleDaily8PMAutoBookingWorker()
        }

        @JavascriptInterface
        fun runLivePortalBookingNow(targetDateIso: String, mealPlan: String) {
            runOnUiThread {
                val req = OneTimeWorkRequestBuilder<DailyMealWorker>()
                    .setConstraints(
                        Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                    )
                    .setInputData(
                        workDataOf(
                            "force_book_date" to targetDateIso,
                            "force_meal_plan" to mealPlan
                        )
                    )
                    .build()
                WorkManager.getInstance(this@MainActivity).enqueue(req)

                // عرض نافذة حية لموقع الزهراء أمام المستخدم ليرى عملية الدخول والحجز وتقرير الوجبات مباشرة
                showInteractivePortalDialog(mealPlan)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showInteractivePortalDialog(mealPlan: String) {
        val dialog = Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen)
        val portalWebView = WebView(this)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(portalWebView, true)
        portalWebView.settings.javaScriptEnabled = true
        portalWebView.settings.domStorageEnabled = true

        val nid = prefs.getNationalId()
        val pwd = prefs.getPassword()
        val wantL = (mealPlan == "both" || mealPlan == "lunch")
        val wantD = (mealPlan == "both" || mealPlan == "dinner")

        portalWebView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val js = """
                    (function() {
                        function setVal(el, val) {
                            var s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                            if (s) s.call(el, val); else el.value = val;
                            el.dispatchEvent(new Event('input', { bubbles: true }));
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                        if (location.pathname.toLowerCase().includes('login')) {
                            var pass = document.querySelector('input[type="password"]');
                            var inputs = document.querySelectorAll('input:not([type="password"]):not([type="hidden"]):not([type="checkbox"])');
                            if (pass && inputs.length > 0 && '$nid'.length === 14) {
                                setVal(inputs[0], '$nid');
                                setVal(pass, '$pwd');
                                var btn = Array.from(document.querySelectorAll('button, input[type="submit"], a, .btn')).find(function(b) {
                                    return (b.textContent || b.value || '').trim().includes('دخول');
                                });
                                if (btn) setTimeout(function() { btn.click(); }, 500);
                            }
                        } else if (location.pathname.toLowerCase().includes('home')) {
                            setTimeout(function() {
                                var bookLink = Array.from(document.querySelectorAll('a, li, span, div')).find(function(el) {
                                    return (el.textContent || '').trim() === 'حجز الوجبات';
                                });
                                if (bookLink) bookLink.click();
                                setTimeout(function() {
                                    var cbs = Array.from(document.querySelectorAll('input[type="checkbox"]:not(:disabled)'));
                                    var saveBtn = Array.from(document.querySelectorAll('button, a, input')).find(function(el) {
                                        return (el.textContent || el.value || '').trim() === 'حفظ';
                                    });
                                    if (saveBtn && cbs.length > 0) {
                                        cbs.forEach(function(cb, i) {
                                            var txt = (cb.parentElement ? cb.parentElement.textContent : '');
                                            if ((txt.includes('غداء') || i === 0) && cb.checked !== $wantL) cb.click();
                                            if ((txt.includes('عشاء') || i === 1) && cb.checked !== $wantD) cb.click();
                                        });
                                        setTimeout(function() { saveBtn.click(); }, 600);
                                    }
                                }, 1500);
                            }, 1000);
                        }
                    })();
                """.trimIndent()
                view?.evaluateJavascript(js, null)
            }
        }

        dialog.setContentView(
            portalWebView,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        dialog.show()
        Toast.makeText(this, "جارٍ تسجيل الدخول وحجز الوجبة تلقائياً على بوابة الزهراء...", Toast.LENGTH_LONG).show()
        portalWebView.loadUrl("https://hostel.cu.edu.eg/studentLogin")
    }
}
